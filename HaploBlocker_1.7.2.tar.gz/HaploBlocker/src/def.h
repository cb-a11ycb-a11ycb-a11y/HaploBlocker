
#ifndef HaploBlocker_def_H
#define HaploBlocker_def_H 1

#define HAPLO_VERSION 1
#define LOCAL_VERSION HAPLO_VERSION


#if ! defined pkg
#define pkg "HaploBlocker" // RFU DELETE
#endif


#endif
